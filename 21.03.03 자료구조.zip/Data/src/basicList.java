import java.util.Scanner;

public class basicList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		int[] num = new int [5];
		
		for(int i = 0; i < num.length; i ++) {
			System.out.print("���ڸ� �Է��Ͻÿ� : ");
			num[i] = sc.nextInt();
		}
		for(int k:num) {
			System.out.println(k);
		}

	}

}
