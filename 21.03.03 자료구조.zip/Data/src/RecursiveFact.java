import java.util.Scanner;

public class RecursiveFact {
	public static int function(int number) {
		int total = number;
		
		for(int i = 1; i < number; i++) {
			total *= i;
		}
		return total;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("���ڸ� �Է��Ͻÿ� :");
		
		int number;
		Scanner scan = new Scanner(System.in);
		
		number = scan.nextInt();
		
		int total = function(number);
		
		System.out.printf("��� : %d", total);
		
		
	}
}